package com.example.jetpack.ui.setting;

import android.arch.lifecycle.ViewModel;

public class SettingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
