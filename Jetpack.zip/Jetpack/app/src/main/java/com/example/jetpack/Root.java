package com.example.jetpack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.jetpack.ui.root.RootFragment;

public class Root extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.root_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, RootFragment.newInstance())
                    .commitNow();
        }
    }
}
