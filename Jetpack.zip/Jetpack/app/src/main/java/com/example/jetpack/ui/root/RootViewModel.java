package com.example.jetpack.ui.root;

import android.arch.lifecycle.ViewModel;

public class RootViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
